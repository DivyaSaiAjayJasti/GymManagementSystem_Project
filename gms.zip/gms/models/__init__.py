from flask import render_template, session, flash, redirect, request, url_for
from app import app
from data.database import *
from datetime import datetime
from bson.objectid import ObjectId



def adminLogin():
    print(request.form["username"])
    if request.form["username"].strip():
                username = request.form["username"]
                password = request.form["password"]
                role = request.form.get("role")
                print(role)
    check = db.admin.find_one({"username": username})
    print(check)
    if check is None:
        flash("Please check the role selected", 'error')
        return redirect(request.url)
    else:
        session["user_id"] = str(check.get('_id'))
        session["username"] = username
        if check.get('password') == password:
            session["user"] = 'admin'
            session["is_authenticated"] = True
            return redirect(url_for('home'))
        else:
            flash("Password mismatch")
            return redirect(request.url)
        
def gymLogin():
    print(request.form["username"])
    if request.form["username"].strip():
                username = request.form["username"]
                password = request.form["password"]
                role = request.form.get("role")
                print(role)
    check = db.gym.find_one({"g_username": username})
    print(check)
    if check is None:
        flash("Please check the role selected", 'error')
        return redirect(request.url)
    else:
        session["user_id"] = str(check.get('_id'))
        session["username"] = username
        if check.get('g_password') == password:
            session["user"] = 'gym'
            session["is_authenticated"] = True
            return redirect(url_for('home'))
        else:
            flash("Password mismatch")
            return redirect(request.url)
        
def memberLogin():
    print(request.form["username"])
    if request.form["username"].strip():
                username = request.form["username"]
                password = request.form["password"]
                role = request.form.get("role")
                print(role)
    check = db.member.find_one({"m_username": username})
    print(check)
    if check is None:
        flash("Please check the role selected", 'error')
        return redirect(request.url)
    else:
        session["user_id"] = str(check.get('_id'))
        session["username"] = username
        if check.get('m_password') == password:
            session["user"] = 'member'
            session["is_authenticated"] = True
            return redirect(url_for('home'))
        else:
            flash("Password mismatch")
            return redirect(request.url)
        
def InstructorLogin():
    print(request.form["username"])
    if request.form["username"].strip():
                username = request.form["username"]
                password = request.form["password"]
                role = request.form.get("role")
                print(role)
    check = db.instructor.find_one({"i_username": username})
    print(check)
    if check is None:
        flash("Please check the role selected", 'error')
        return redirect(request.url)
    else:
        session["user_id"] = str(check.get('_id'))
        session["username"] = username
        if check.get('i_password') == password:
            if check.get('is_verified') == True:
                session["user"] = 'instructor'
                session["is_authenticated"] = True
                session['is_instructorverified'] = True
                
            else:
                session['is_instructorverified'] = False
                
        else:
            flash("Password mismatch")
            return redirect(request.url)
        


def customerRegister():
    print("register")
    first_name = request.form['m_firstname']
    last_name = request.form['m_lastname']
    username = request.form['m_username']
    email = request.form['m_email']
    password = request.form['m_password']
    gender = request.form['m_gender']
    dob = request.form['m_dob']
    member_type = request.form['m_membertype']
    phone_number = request.form['m_phone']
    address = request.form['m_address']
    startdate = request.form['m_startdate']

    member = {"m_firstname":first_name, "m_lastname": last_name,"m_username":username, "m_email": email,"m_password": password, "m_dob": dob, "m_address": address, "m_phone": phone_number, "m_gender": gender,"m_membertype": member_type, "m_startdate": startdate}

    check = db.member.find_one({"email":email})

    if check is None:
          db.member.insert_one(member)
    else:
         flash("Member already exists")


def addInstructor():
    print("add instructor")
    first_name = request.form['i_firstname']
    last_name = request.form['i_lastname']
    username = request.form['i_username']
    email = request.form['i_email']
    password = request.form['i_password']
    gender = request.form['i_gender']
    dob = request.form['i_dob']
    phone_number = request.form['i_phone']
    address = request.form['i_address']
    i_specialization = request.form['i_specialization']
    i_experience = request.form['i_experience']

    instructor = {"i_firstname":first_name, "i_lastname": last_name,"i_username":username, "i_email": email,"i_password": password, "i_dob": dob, "i_address": address, "i_phone": phone_number, "i_gender": gender,"i_specialization": i_specialization,"i_experience": i_experience,"is_verified": False}

    check = db.instructor.find_one({"email":email})

    if check is None:
        db.instructor.insert_one(instructor)
        
    else:
        flash("Instructor already exists") 
        

def addWorkoutplan():
    print("add instructor")
    price = request.form['price']
    w_startdate = request.form['start_date']
    w_enddate = request.form['end_date']
    plan_name = request.form['plan_name']
    plan_details = request.form['plan_details']
    plan_membertype = request.form['plan_membertype']

    w_plan = {"i_id":session['user_id'], "members":[], "w_price": int(price),"w_planname":plan_name, "w_startdate":w_startdate, "w_enddate": w_enddate,"w_plandetails": plan_details,"w_membertype": plan_membertype}

    check = db.workoutplan.find_one({"w_planname":plan_name})

    if check is None:
        db.workoutplan.insert_one(w_plan)
        session['workouterror'] = False
    else:
        flash("Workout plan with this name already exists") 
        session['workouterror'] = True

     

def addPayment(w_id):
    print("add payment")
    total_amount = request.form['total_amount']
    name_oncard = request.form['name_oncard']
    card_no = request.form['card_no']
    cvv = request.form['cvv']
    exp_date = request.form['exp_date']

    w_plan_applied = {"m_id":session['user_id'],"w_id":w_id, "a_date":str(datetime.now().date()), "a_totalamount": int(total_amount),"a_status":"Processed", "card_no": card_no,"name_oncard": name_oncard,"cvv":cvv,"expiry":exp_date}

    db.applied.insert_one(w_plan_applied)

    doc = db.workoutplan.find_one({"_id": ObjectId(w_id), "members":session['user_id']})
    if doc is None:
        db.workoutplan.update_one({"_id":ObjectId(w_id)}, {"$push": {"members":session['user_id']}})
    else:
         print("memberid is in the list")

def instructorplans():
    pipeline =[
          {"$unwind": "$members"},
          {"$group":{"_id":session['user_id'], "count":{"$sum":1}}}
    ]
    results =db.workoutplan.aggregate(pipeline)
    return results

def updategymdata():
    print("update gym")
    g_name = request.form['g_name']
    g_description = request.form['g_description']
    g_username = request.form['g_username']
    g_email = request.form['g_email']
    g_password = request.form['g_password']
    g_phone_number = request.form['g_phone_number']
    g_address = request.form['g_address']

    gym = {"g_name": g_name, "g_description": g_description, "g_username": g_username, "g_email": g_email, "g_password": g_password, "g_phone":g_phone_number, "g_address": g_address}
    print(gym)
    db.gym.update_one({"_id":ObjectId("64aa160d7391e18dbc7f76e8")},
                  {"$set":gym}
                  )
    
def workoutplansadminData():
    applied = db.applied.find({})

    newplans =[]
    for apply in applied:
        m_detail = db.member.find_one({"_id": ObjectId(apply['m_id'])})
        w_detail = db.workoutplan.find_one({"_id":ObjectId(apply['w_id'])})
        i_detail = db.instructor.find_one({"_id":ObjectId(w_detail['i_id'])})

        if m_detail is not None:
            combined_dict = {**apply,**m_detail,**w_detail,**i_detail}
        else:
             combined_dict = apply
        newplans.append(combined_dict)
    print(newplans)
    return newplans

def planDetails():
    workoutplans = list(db.workoutplan.find({}))
              
    newplans =[]
    for workout in workoutplans:
        i_detail = db.instructor.find_one({"_id":ObjectId(workout['i_id'])})
        if i_detail is not None:
            combined_dict = {**workout,**i_detail}
        else:
             combined_dict = workout
        newplans.append(combined_dict)
    print(newplans)

    return newplans


def getMemberData():
    workoutplans = list(db.workoutplan.find({"i_id":session['user_id']}))
    for workoutplan in workoutplans:
        member_details_list = []
        print("memberid")
        # For each member identifier in the document...
        for member_id in workoutplan["members"]:
            # If the member id is not empty (as the first one seems to be)...
            if member_id:
            # Get the member's details and append them to the list.
                details = db.member.find_one({"_id":ObjectId(member_id)})
                member_details_list.append(details)

        print(member_details_list)

        workoutplan['members'] = member_details_list

    return workoutplans  





