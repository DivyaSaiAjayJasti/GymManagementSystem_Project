from models import *
from flask import render_template, session, flash, redirect, request, url_for
from app import app
from bson.objectid import ObjectId

#######################################################
@app.route("/", methods=['GET','POST'])
def home():
    if 'user' not in session:
        return redirect(url_for('login'))
    else:
        if session['user']== 'admin':
            member_count = db.member.count_documents({})
            instructor_count = db.instructor.count_documents({})
            workoutplan_count = db.workoutplan.count_documents({})
            return render_template('admin/admin.html',member_count=member_count, instructor_count=instructor_count, workoutplan_count=workoutplan_count)
        elif session['user']== 'gym':
            member_count = db.member.count_documents({})
            instructor_count = db.instructor.count_documents({})
            workoutplan_count = db.workoutplan.count_documents({})
            return render_template('gym/gym.html', member_count=member_count, instructor_count=instructor_count, workoutplan_count=workoutplan_count)
        elif session['user']== 'instructor':
            results = instructorplans()
            print("##")
            print(results)
            return render_template('instructor/instructor.html', results=results)
        else:
            newplans = planDetails()
            myworkoutplans = list(db.applied.find({"m_id":session['user_id']}))
            return render_template('member/member.html', workoutplans = newplans,myworkoutplans=myworkoutplans)
        

########################################################
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        print("login")
        role = request.form.get("role")
        if role == "admin":
            adminLogin()
            return redirect(url_for('home'))
        elif role == "gym":
            gymLogin()
            return redirect(url_for('home'))
        elif role == "instructor":
            InstructorLogin()
            if session["is_instructorverified"] == True:
                return redirect(url_for('home'))
            else:
                return redirect(url_for('resetpassword'))
        else:
            memberLogin()
            return redirect(url_for('home'))
    else:
        if 'guest' not in session:
            print("guest is not in session")
        else: 
            session.pop('guest')
    return render_template('includes/login.html')

#############################################################
    
@app.route("/logout", methods=['GET','POST'])
def logout():
    session.pop('username', None)  # remove user session
    session.pop('user')
    if 'guest' not in session:
        print("guest is not in session")
    else: 
        session.pop('guest')
    session.clear()
    return redirect(url_for("login"))  # redirect to home page with message


###################################################################

@app.route("/register", methods=['GET', 'POST'])
def register():
    if request.method == "POST":
        customerRegister()
        return redirect(url_for('login'))
    else:
        todaysdate = str(datetime.now().date())
        yeardate = str(datetime.now().date())
        return render_template("includes/register.html")
    
#################################################################

@app.route("/addinstructor", methods=['GET','POST'])
def addinstructor():
    if request.method == "POST":
        addInstructor()
        return redirect(url_for('home'))
    else:
        return render_template('gym/addinstructor.html')
    
#################################################################

@app.route("/addworkoutplan", methods=['GET','POST'])
def addworkoutplan():
    if request.method == "POST":
        addWorkoutplan()
        if session["workouterror"] == True:
            return redirect(url_for('addworkoutplan'))
        else:
           return redirect(url_for('home')) 
    else:
        return render_template('instructor/addworkoutplan.html')
    

#################################################################

@app.route("/workoutplans", methods=['GET','POST'])
def workoutplans():
    session["guest"]='guest'
    newplans = planDetails()
    return render_template('member/workoutplans.html', workoutplans = newplans)


###################################################################

@app.route("/addmember", methods=['GET', 'POST'])
def addmember():
    if request.method == "POST":
        customerRegister()
        return redirect(url_for('home'))
    else:
        return render_template("gym/addmembers.html")
    
###################################################################

@app.route("/booking+<i_id>+<plan_name>", methods=['GET', 'POST'])
def booking(i_id,plan_name):
    
    if request.method == "POST":
        
        return redirect(url_for('home'))
    else:
        instructor = db.instructor.find_one({"_id":ObjectId(i_id)})
        plan = db.workoutplan.find_one({"w_planname":plan_name})
        print(plan)
        return render_template("member/booking.html", instructor=instructor,plan=plan)
    
#################################################################

@app.route("/payment+<w_id>", methods=['GET','POST'])
def payment(w_id):
    if request.method == "POST":
        addPayment(w_id)
        return redirect(url_for('paymentsucess'))
    else:
        session['w_id'] = w_id
        workoutplan = db.workoutplan.find_one({"_id":ObjectId(w_id)})
        return render_template('member/payment.html',workoutplan=workoutplan)
    
#################################################################

@app.route("/paymentsucess", methods=['GET','POST'])
def paymentsucess():
    if request.method == "POST":
        addPayment(session['w_id'])
        return render_template('member/success.html')
    
#################################################################

@app.route("/myworkoutplans", methods=['GET','POST'])
def myworkoutplans():
    workoutplan_applied = db.applied.find({"m_id":session['user_id']})
    newplans = []
    for wplan_applied in workoutplan_applied:
        print(wplan_applied['w_id'])
        w_plan = db.workoutplan.find_one({"_id": ObjectId(wplan_applied['w_id'])})
        i_detail = db.instructor.find_one({"_id":ObjectId(w_plan['i_id'])})
        print(w_plan)
        if w_plan is not None:
            combined_dict = {**wplan_applied, **w_plan, **i_detail}
        else:
            combined_dict = wplan_applied
        newplans.append(combined_dict)
    print(newplans)
    

    return render_template('member/myworkoutplans.html',newplans=newplans)

#################################################################

@app.route("/updategym", methods=['GET','POST'])
def updategym():
    if request.method == "POST":
        updategymdata()
        return redirect(url_for('home'))
    else:
        gym = db.gym.find_one({"g_username":"abc"})
        print(gym)
        return render_template('admin/updategym.html', gym=gym)
    

#################################################################

@app.route("/editinstructor", methods=['GET','POST'])
def editinstructor():
    if request.method == "POST":
        if request.form['request_type'] == 'request1':
            instructor = db.instructor.find_one({"i_email": request.form['i_email']})
            return render_template('admin/editinstructor.html', instructor=instructor)
        elif request.form['request_type'] == 'request2':
            action = request.form['action']
            if action == 'update':
                quantities = request.form.to_dict()
                print(quantities)
                quantities.pop('request_type')
                db.instructor.update_one({"i_email":quantities['i_email']},
                                     {"$set":quantities})
                return redirect(url_for('home'))
            elif action == 'add':
                addInstructor()
                return redirect(url_for('home'))
            else:
                return redirect(url_for('home'))
    else:
        
        return render_template('admin/editinstructor.html',instructor={})
    
#################################################################

@app.route("/editmember", methods=['GET','POST'])
def editmember():
    if request.method == "POST":
        if request.form['request_type'] == 'request1':
            member = db.member.find_one({"m_email": request.form['m_email']})
            return render_template('admin/editmember.html', member=member)
        elif request.form['request_type'] == 'request2':
            action = request.form['action']
            if action == 'update':
                quantities = request.form.to_dict()
                print(quantities)
                quantities.pop('request_type')
                db.member.update_one({"m_email":quantities['m_email']},
                                     {"$set":quantities})
                return redirect(url_for('home'))
            elif action == 'add':
                customerRegister()
                return redirect(url_for('home'))
            else:
                return redirect(url_for('home'))
    else:
        
        return render_template('admin/editmember.html',member={})
    
#################################################################

@app.route("/editworkoutplan", methods=['GET','POST'])
def editworkoutplan():
    if request.method == "POST":
        if request.form['request_type'] == 'request1':
            workoutplan = db.workoutplan.find_one({"w_planname": request.form['w_planname']})
            return render_template('instructor/editworkoutplan.html', workoutplan = workoutplan)
        elif request.form['request_type'] == 'request2':
            quantities = request.form.to_dict()
            print(quantities)
            quantities.pop('request_type')
            db.workoutplan.update_one({"w_planname":quantities['w_planname']},
                                     {"$set":quantities})
            return redirect(url_for('home'))
    else:
        
        return render_template('instructor/editworkoutplan.html',workoutplan={})
    
#################################################################

@app.route("/viewworkoutplan", methods=['GET','POST'])
def viewworkoutplan():
    if request.method == "POST":
        return redirect(url_for('home'))
    else:
        workoutplans=getMemberData()
        
        return render_template('instructor/viewworkoutplans.html',workoutplans=workoutplans)

#################################################################

@app.route("/workoutplansadmin", methods=['GET','POST'])
def workoutplansadmin():
    if request.method == "POST":
        return redirect(url_for('home'))
    else:
        newplans = workoutplansadminData()
        return render_template('admin/viewworkoutplansadmin.html',newplans=newplans)
    
###################################################################
    
@app.route("/resetpassword", methods=['GET', 'POST'])
def resetpassword():
    if request.method == "POST":
        i_email = request.form['i_email']
        old_password = request.form['old_password']
        new_password = request.form['new_password']
        check = db.instructor.find_one({"i_email": i_email})
        print(check)
        if check is None:
            flash("Please check the provided details")
            return redirect(request.url)
        else:
            if check.get('i_password') == old_password:
                dbResponse = db.instructor.update_one({"i_email": i_email},
                                                    {"$set": {"i_password": new_password,"is_verified":True}})
                print("password updated")
                return redirect(url_for('home'))
            else:
                flash("password mismatch")
                return redirect(request.url)
    else:
        return render_template("includes/resetpassword.html")